import React from 'react'

const AlertsSignup = () => {
  return (
    <div className='w-full bg-white flex justify-center text-lg py-5 shadow-md cursor-pointer' >
      Sign up for alerts
    </div>
  )
}

export default AlertsSignup
